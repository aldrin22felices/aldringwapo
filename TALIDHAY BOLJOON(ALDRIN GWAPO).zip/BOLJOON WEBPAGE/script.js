 // Add a scroll event listener to show/hide the scroll-to-top button
 window.addEventListener('scroll', function () {
    var scrollButton = document.getElementById('scroll-to-top');
    if (window.scrollY > 100) {
        scrollButton.classList.add('active');
    } else {
        scrollButton.classList.remove('active');
    }
});

// Add smooth scroll behavior
document.getElementById('scroll-to-top').addEventListener('click', function (e) {
    e.preventDefault();
    // Scroll to the top of the page with a smooth transition
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});